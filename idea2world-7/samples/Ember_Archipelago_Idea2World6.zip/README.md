# Floating ember archipelago

Created with **Idea2World 6.0** from this idea:

> A floating ember archipelago at dusk: obsidian bridges between volcanic islets, a broken observatory on the tallest spire, and lantern-lit shrines where players collect star shards

| | |
| --- | --- |
| Genre | general_adventure |
| Art direction | Cosmic Art Direction / cosmic |
| World size | 1800 studs |
| Districts | 6 |
| Landmarks | 13 |
| Routes | 17 |
| Assets | 25 definitions, 595 placements |
| Visual score | 94.1 |
| Studio build | verified |

## How to open it

1. `luau/` is a complete module project. Drop it into `ServerScriptService` as a Folder named
   `Idea2World_Generated_Map` (see `luau/README_INSTALL.md`).
2. In Studio: **Robot icon → Assistant → Manage MCP Servers → Enable Studio as MCP server**, then
   point Idea2World at it so it can build, capture and playtest for you.
3. Easiest path: paste `CommandBar_Install.lua` into the Studio Command Bar in Edit mode. It installs
   the modules and builds the world immediately.

## What is verified, and what is not

- The generated Luau **was executed** against a simulated Roblox DataModel (parts, models, terrain fills and in-Studio validation all ran).
- The world was **not built in Roblox Studio in this run**. Geometry is planned and validated, but nothing here proves the render looks right until it is built.
- The visual score is a **deterministic heuristic** based on layout, palette, asset recipes and budgets — not a review of a rendered image.
- No AI provider was configured, so the deterministic planner made the decisions. Add an API key to have a model direct the crew.

## Contents

- `world_spec.json` — the full contract (terrain, districts, routes, landmarks, assets, placements)
- `luau/` — the generated modular build system
- `CommandBar_Install.lua` — one-paste installer
- `design/game_design.json`, `design/art_direction.json` — the creative brief
- `reports/` — validation, QA, performance, visual review and build reports
- `preview/map_plan.svg` — top-down plan with districts, routes, landmarks and spawn
- `assets/asset_manifest.json`, `assets/asset_import_plan.json` — asset definitions and mesh queue
